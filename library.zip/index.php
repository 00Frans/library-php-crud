<?php
include "connect.php";


if (isset($_POST['add'])) {
    $isbn = $_POST['isbn'];
    $title = $_POST['title'];
    $copyright = $_POST['copyright'];
    $edition = $_POST['edition'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $sql = "INSERT INTO library (isbn, title, copyright, edition,  quantity, price) VALUES ('$isbn', '$title', '$copyright', '$edition', '$quantity','$price') ";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $message = "Item added successfully";
        header("location:index.php");
    } else {
        die(mysqli_error($conn));
    }
}

//SEARCH


if (isset($_POST['search'])) {
    $isbn = $_POST['isbn'];

    $query = "SELECT * FROM library WHERE isbn = '$isbn'";
    $result = mysqli_query($conn, $query);
    $bookDetails = mysqli_fetch_assoc($result);

    if ($bookDetails) {
        // If the book with the given ISBN is found, display its details in the form.
        $isbn = $bookDetails['isbn'];
        $title = $bookDetails['title'];
        $copyright = $bookDetails['copyright'];
        $edition = $bookDetails['edition'];
        $price = $bookDetails['price'];
        $quantity = $bookDetails['quantity'];
        $message = "Item found";
    } else {
        // If the book is not found, show an error message.
        $message = "Item not found";
    }
}


// UPDATE
if (isset($_POST['edit'])) {
    $id = $_POST['edit']; // Get the book ID to be edited

    // Fetch the book details based on the ID
    $sql = "SELECT * FROM library WHERE id=$id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    // Store the book details in variables
    $isbn = $row['isbn'];
    $title = $row['title'];
    $copyright = $row['copyright'];
    $edition = $row['edition'];
    $quantity = $row['quantity'];
    $price = $row['price'];

    // Display the book details in the form (same as before)
    // ...
}

// UPDATE (after the user edits and clicks "SAVE CHANGES")
if (isset($_POST['save_changes'])) {
    $id = $_POST['edit_id']; // Get the book ID to be edited

    $isbn = $_POST['isbn'];
    $title = $_POST['title'];
    $copyright = $_POST['copyright'];
    $edition = $_POST['edition'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    // Update the book details in the database
    $sql = "UPDATE library SET isbn='$isbn', title='$title', copyright='$copyright', edition='$edition', price='$price', quantity='$quantity' WHERE id=$id";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        $message = "Updated Successfully!";
    } else {
        die(mysqli_error($conn));
    }
}

//Delete

if (isset($_POST['delete'])) {
    $id = $_POST['delete']; // Get the book ID to be deleted

    $sql = "DELETE FROM library WHERE id=$id ";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $message = "Deleted Successfully!";
        header("location:index.php");
    } else {
        die(mysqli_error($conn));
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>HOME</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' href='css/styles.css'>

</head>

<body>
    <div class="w3-container w3-padding-16">

        <form method="POST">
            <div class="w3-row">
                <div class="w3-twothird">
                    <label>ISBN</label>
                    <input class="w3-input" type="text" name="isbn" value="<?= isset($isbn) ? $isbn : ''; ?>">

                    <label>Title</label>
                    <input class="w3-input" type="text" name="title"
                        value="<?= isset($bookDetails['title']) ? $bookDetails['title'] : ''; ?>">

                    <label>Copyright</label>
                    <input class="w3-input" type="text" name="copyright"
                        value="<?= isset($bookDetails['copyright']) ? $bookDetails['copyright'] : ''; ?>">

                    <label>Edition</label>
                    <input class="w3-input" type="text" name="edition"
                        value="<?= isset($bookDetails['edition']) ? $bookDetails['edition'] : ''; ?>">

                    <label>Price</label>
                    <input class="w3-input" type="text" name="price"
                        value="<?= isset($bookDetails['price']) ? $bookDetails['price'] : ''; ?>">

                    <label>Quantity</label>
                    <input class="w3-input" type="text" name="quantity"
                        value="<?= isset($bookDetails['quantity']) ? $bookDetails['quantity'] : ''; ?>">
                </div>

                <div class="w3-container w3-rest w3-panel w3-padding-16">
                    <div class="w3-row">
                        <button class="w3-button w3-green" name="add">ADD</button>
                        <button class="w3-button w3-blue" name="search">SEARCH</button>
                    </div>
                    <div class="w3-row w3-padding-16">
                        <input type="hidden" name="edit_id" value="<?= $bookDetails['id']; ?>">
                        <button class="w3-button w3-blue" name="save_changes">SAVE CHANGES</button>
                        <button class="w3-button w3-red" name="delete"
                            value="<?= $bookDetails['id']; ?>">DELETE</button>
                        <!-- <?php if (!empty($bookDetails)): ?>
                           //Show the "SAVE CHANGES" button if book details are found -->
                         <!-- <button class="w3-button w3-blue" name="save_changes">SAVE CHANGES</button> -->
                         <!-- Add a hidden input field to store the book ID to be edited -->
                         <!-- <input type="hidden" name="edit_id" value="<?= $bookDetails['id']; ?>"> -->

                         <!-- <button class="w3-button w3-red" name="delete" -->
                         <!-- value="<?= $bookDetails['id']; ?>">DELETE</button> -->
                         <!-- <?php endif; ?> -->
                    </div>
                    <div class="w3-container w3-padding-16">
                        <div class="w3-row">
                            <?php if (!empty($message)): ?>
                                <label class="w3-tag w3-teal w3-padding-46">
                                    <?= $message; ?>
                                </label>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="w3-container w3-padding-16">
        <table class="w3-table w3-striped w3-bordered">
            <thead>
                <tr class=" w3-green">
                    <th>ISBN</th>
                    <th>Title</th>
                    <th>Copyright</th>
                    <th>Edition</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM library";
                $result = mysqli_query($conn, $sql);

                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $isbn = $row['isbn'];
                        $title = $row['title'];
                        $copyright = $row['copyright'];
                        $edition = $row['edition'];
                        $quantity = $row['quantity'];
                        $price = $row['price'];
                        $total = $row['quantity'] * $row['price'];
                        echo '<tr>
                        <td>' . $isbn . '</td>
                        <td>' . $title . '</td>
                        <td>' . $copyright . '</td>
                        <td>' . $edition . '</td>
                        <td>' . $quantity . '</td>
                        <td>' . $price . '</td>
                        <td>' . $total . '</td>
                    </tr>';
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>

</html>