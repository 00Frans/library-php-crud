<?php 
    $con = mysqli_connect('localhost','root','','book');

    // if($con){
    //     echo "db connected";
    // }
?>